package ChatBotAndTest;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Scanner;

import opennlp.tools.tokenize.TokenizerME;
import opennlp.tools.tokenize.TokenizerModel;

public class GreetTest {

	public static void main(String[] args) throws Exception {
		
		System.out.println("Please enter the number for the language you would like to use: ");
		System.out.println("1: English");
		System.out.println("2: French");
		System.out.println("3: Spanish");
		System.out.println("4: Japanese");
		Scanner input = new Scanner(System.in);
		int num = input.nextInt();
		String lang;
		if(num == 1) {
			lang = "en";
		} else if(num == 2) {
			lang = "fr";
		} else if(num == 3) {
			lang = "es";
		} else {
			lang = "ja";
		}
		
		System.out.println(translate("Hello and welcome to our Chat bot concerning mental health.", "en", lang));
		ThreadSleep(2000);
		System.out.println(translate("If you would, please enter a little bit about yourself, so that we may get to know you better.", "en", lang));
		input.next();
		String patientInformation = input.nextLine();
		System.out.println(translate("And finally, please enter your name or username: ", "en", lang));
		String username = input.nextLine();
		username.trim();
		ChatBot chat = new ChatBot();
		chat.Greet(username, input, Tokenizing(patientInformation));
		input.close();
		
	}
	
	public static String translate(String text, String langFrom, String langTo) throws IOException {
        String urlStr = "https://script.google.com/macros/s/AKfycbyl2YVijacbt1DgzOtg7Qo6iay7_qq0bkQewXkVTWSqA2PSGifltnay9Pu9pMeVMyMf2A/exec" + "?q=" + URLEncoder.encode(text, "UTF-8") + "&target=" + langTo + "&source=" + langFrom;
        StringBuilder translate = new StringBuilder();
        URL url = new URL(urlStr);
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        con.setRequestProperty("User-Agent", "Mozilla/5.0");
        BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
        String input = "";
        while ((input = in.readLine()) != null) {
            translate.append(input);
        }
        in.close();
        return translate.toString();
    }
      

	// Suspends the thread to give the illusion that the machine is typing out a response.
	private static void ThreadSleep(int milliseconds) {
		try {
			Thread.sleep(milliseconds);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	public static String[] Tokenizing(String patientInfo) throws IOException {
		String path = new File("src/Resources/opennlp-en-ud-ewt-tokens-1.0-1.9.3.bin").getAbsolutePath();
		
		InputStream modelIn = new FileInputStream(path);
		TokenizerModel model = new TokenizerModel(modelIn);
		if (modelIn != null) {
			try {
				modelIn.close();
			} 
			catch (IOException e) {}
		}
		TokenizerME tokenizer = new TokenizerME(model);
		String tokens[] = tokenizer.tokenize(patientInfo);
		return tokens;
	}
		
}

